INSERT INTO pet VALUES ('9','Puffball','Diane','hamster','f','1999-03-30',NULL);
